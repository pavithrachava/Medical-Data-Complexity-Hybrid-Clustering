import os
import sqlite3
import pandas as pd
import numpy as np
from flask import Flask, render_template, request, redirect, url_for, session, flash, jsonify, send_file
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename
from sklearn.preprocessing import StandardScaler
from sklearn.cluster import DBSCAN
import skfuzzy as fuzz
from sklearn.metrics import silhouette_score, davies_bouldin_score, adjusted_rand_score
import groq
from groq import Groq
from dotenv import load_dotenv

load_dotenv()

app = Flask(__name__)
app.secret_key = 'fuzzy_dbscan_hybrid_secret_key'
app.config['UPLOAD_FOLDER'] = 'uploads'
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # 16MB limit

GROQ_API_KEY = "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"
client = Groq(api_key=GROQ_API_KEY)

def get_db_connection():
    conn = sqlite3.connect('database.db')
    conn.row_factory = sqlite3.Row
    return conn

# -----------------------------------------------------------------------------
# HYBRID MODEL IMPLEMENTATION
# -----------------------------------------------------------------------------

def apply_hybrid_model(data, labels=None):
    scaler = StandardScaler()
    data_scaled = scaler.fit_transform(data)
    n_clusters = 3
    cntr, u, u0, d, jm, p, fpc = fuzz.cluster.cmeans(
        data_scaled.T, n_clusters, 2, error=0.005, maxiter=1000, init=None
    )
    fcm_labels = np.argmax(u, axis=0)
    dbscan = DBSCAN(eps=0.5, min_samples=5)
    dbscan_labels = dbscan.fit_predict(data_scaled)
    final_labels = fcm_labels.copy().astype(float)
    membership_scores = np.max(u, axis=0)

    for i in range(len(dbscan_labels)):
        if dbscan_labels[i] == -1:  # DBSCAN marks as noise
            membership_scores[i] *= 0.5
    # Step 5: Metrics
    sil_score = silhouette_score(data_scaled, fcm_labels)
    db_score = davies_bouldin_score(data_scaled, fcm_labels)
    ari = adjusted_rand_score(labels, fcm_labels) if labels is not None else 0.0

    return {
        'silhouette': sil_score,
        'davies_bouldin': db_score,
        'ari': ari,
        'labels': fcm_labels,
        'membership': membership_scores,
        'centroids': cntr
    }

# s=b-a/max(a,b) 0.5 to 1+ +v 0 to 0.5 -v
# db= 1/n E max(si+sj/Mij)
def analyze_with_groq(predicted_cluster, membership_score):
    if not client:
        return "GROQ API Key not configured. Unable to generate AI analysis."
    
    prompt = f"""
    As a Medical AI Specialist, analyze the following prediction results:
    - Predicted Cluster: {predicted_cluster} (0: Low Risk, 1: Moderate Risk, 2: High Risk)
    - Membership Confidence Score: {membership_score:.2f}

    Provide a human-readable medical insight and explanation of what this detection means for a patient.
    Keep it professional and concise.
    """
    
    try:
        completion = client.chat.completions.create(
            model="llama-3.3-70b-versatile",
            messages=[{"role": "user", "content": prompt}],
            temperature=0.7,
            max_tokens=200
        )
        return completion.choices[0].message.content
    except Exception as e:
        return f"Error connecting to GROQ: {str(e)}"

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/user/register', methods=['GET', 'POST'])
def user_register():
    if request.method == 'POST':
        name = request.form['name']
        email = request.form['email']
        password = generate_password_hash(request.form['password'])
        
        conn = get_db_connection()
        try:
            conn.execute('INSERT INTO users (name, email, password) VALUES (?, ?, ?)', (name, email, password))
            conn.commit()
            flash('Registration successful!', 'success')
            return redirect(url_for('user_login'))
        except sqlite3.IntegrityError:
            flash('Email already exists!', 'error')
        finally:
            conn.close()
    return render_template('user_register.html')

@app.route('/user/login', methods=['GET', 'POST'])
def user_login():
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']
        
        conn = get_db_connection()
        user = conn.execute('SELECT * FROM users WHERE email = ?', (email,)).fetchone()
        conn.close()
        
        if user and check_password_hash(user['password'], password):
            session['user_id'] = user['id']
            session['user_name'] = user['name']
            return redirect(url_for('user_dashboard'))
        flash('Invalid credentials!', 'error')
    return render_template('user_login.html')

@app.route('/user/dashboard')
def user_dashboard():
    if 'user_id' not in session: return redirect(url_for('user_login'))
    return render_template('user_dashboard.html')

# @app.route('/user/predict', methods=['POST'])
# def user_predict():
#     if 'user_id' not in session: return redirect(url_for('user_login'))
#     features = [float(request.form[f'f{i}']) for i in range(1, 5)]
#     data = np.array([features])
    
#     predicted_cluster = np.random.randint(0, 3) 
#     membership_score = np.random.uniform(0.7, 0.99)
    
#     ai_analysis = analyze_with_groq(predicted_cluster, membership_score)
    
#     conn = get_db_connection()
#     conn.execute('INSERT INTO predictions (user_id, predicted_cluster, membership_score, groq_ai_analysis) VALUES (?, ?, ?, ?)',
#                  (session['user_id'], predicted_cluster, membership_score, ai_analysis))
#     conn.commit()
#     conn.close()
    
#     return render_template('prediction_results.html', cluster=predicted_cluster, score=membership_score, analysis=ai_analysis)

@app.route('/user/predict', methods=['POST'])
def user_predict():
    if 'user_id' not in session:
        return redirect(url_for('user_login'))


    features = [float(request.form[f'f{i}']) for i in range(1, 5)]
    user_data = np.array([features])
    conn = get_db_connection()
    dataset = conn.execute('SELECT * FROM datasets ORDER BY id DESC LIMIT 1').fetchone()
    conn.close()

    file_path = os.path.join(app.config['UPLOAD_FOLDER'], dataset['filename'])
    df = pd.read_csv(file_path)

    numeric_df = df.select_dtypes(include=[np.number])

    if 'target' in numeric_df.columns:
        numeric_df = numeric_df.drop('target', axis=1)


    full_data = np.vstack([numeric_df.values, user_data])
    scaler = StandardScaler()
    data_scaled = scaler.fit_transform(full_data)
    n_clusters = 3
    cntr, u, _, _, _, _, _ = fuzz.cluster.cmeans(
        data_scaled.T,
        n_clusters,
        2,
        error=0.005,
        maxiter=1000
    )

    user_membership = u[:, -1]
    predicted_cluster = np.argmax(user_membership)
    membership_score = np.max(user_membership)
    dbscan = DBSCAN(eps=0.5, min_samples=5)
    dbscan_labels = dbscan.fit_predict(data_scaled)
    if dbscan_labels[-1] == -1:
        membership_score *= 0.5  
    ai_analysis = analyze_with_groq(predicted_cluster, membership_score)

    conn = get_db_connection()
    conn.execute(
        'INSERT INTO predictions (user_id, predicted_cluster, membership_score, groq_ai_analysis) VALUES (?, ?, ?, ?)',
        (session['user_id'], int(predicted_cluster), float(membership_score), ai_analysis)
    )
    conn.commit()
    conn.close()

    return render_template(
        'prediction_results.html',
        cluster=predicted_cluster,
        score=membership_score,
        analysis=ai_analysis
    )






@app.route('/user/profile')
def profile():
    if 'user_id' not in session: return redirect(url_for('user_login'))
    conn = get_db_connection()
    predictions = conn.execute('SELECT * FROM predictions WHERE user_id = ? ORDER BY created_at DESC', (session['user_id'],)).fetchall()
    conn.close()
    return render_template('profile.html', predictions=predictions)

# --- ADMIN MODULE ---

@app.route('/admin/login', methods=['GET', 'POST'])
def admin_login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        
        conn = get_db_connection()
        admin = conn.execute('SELECT * FROM admins WHERE username = ?', (username,)).fetchone()
        conn.close()
        
        if admin and check_password_hash(admin['password'], password):
            session['admin_id'] = admin['id']
            return redirect(url_for('admin_dashboard'))
        flash('Invalid admin credentials!', 'error')
    return render_template('admin_login.html')

@app.route('/admin/dashboard')
def admin_dashboard():
    if 'admin_id' not in session: return redirect(url_for('admin_login'))
    conn = get_db_connection()
    datasets = conn.execute('SELECT * FROM datasets').fetchall()
    users = conn.execute('SELECT * FROM users').fetchall()
    conn.close()
    return render_template('admin_dashboard.html', datasets=datasets, users=users)

@app.route('/admin/upload', methods=['POST'])
def admin_upload():
    if 'admin_id' not in session: return redirect(url_for('admin_login'))
    file = request.files['file']
    if file and file.filename.endswith('.csv'):
        filename = secure_filename(file.filename)
        file_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
        file.save(file_path)
        
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute('INSERT INTO datasets (filename) VALUES (?)', (filename,))
        conn.commit()
        conn.close()
        flash('File uploaded successfully!', 'success')
    return redirect(url_for('admin_dashboard'))

@app.route('/admin/train/<int:dataset_id>')
def train_model_view(dataset_id):
    if 'admin_id' not in session: return redirect(url_for('admin_login'))
    conn = get_db_connection()
    dataset = conn.execute('SELECT * FROM datasets WHERE id = ?', (dataset_id,)).fetchone()
    conn.close()
    return render_template('train_model.html', dataset=dataset)

@app.route('/admin/perform_training/<int:dataset_id>')
def perform_training(dataset_id):
    if 'admin_id' not in session: return redirect(url_for('admin_login'))
    
    conn = get_db_connection()
    dataset = conn.execute('SELECT * FROM datasets WHERE id = ?', (dataset_id,)).fetchone()
    
    file_path = os.path.join(app.config['UPLOAD_FOLDER'], dataset['filename'])
    df = pd.read_csv(file_path)
    
    # Simple preprocessing: drop non-numeric or labels
    numeric_df = df.select_dtypes(include=[np.number])
    if 'target' in df.columns:
        labels = df['target']
        numeric_df = numeric_df.drop('target', axis=1, errors='ignore')
    else:
        labels = None
        
    results = apply_hybrid_model(numeric_df, labels)
    
    conn.execute('INSERT INTO model_training_results (dataset_id, silhouette_score, davies_bouldin_score, ari_score) VALUES (?, ?, ?, ?)',
                 (dataset_id, results['silhouette'], results['davies_bouldin'], results['ari']))
    conn.commit()
    conn.close()
    
    return render_template('model_results.html', results=results)

@app.route('/api/chart-data')
def chart_data():
    conn = get_db_connection()
    results = conn.execute('SELECT * FROM model_training_results ORDER BY created_at DESC LIMIT 5').fetchall()
    predictions = conn.execute('SELECT predicted_cluster, COUNT(*) as count FROM predictions GROUP BY predicted_cluster').fetchall()
    conn.close()
    
    return jsonify({
        'metrics': {
            'labels': [f"ID: {r['id']}" for r in results],
            'silhouette': [r['silhouette_score'] for r in results],
            'db': [r['davies_bouldin_score'] for r in results]
        },
        'ratio': {
            'labels': [f"Cluster {p['predicted_cluster']}" for p in predictions],
            'data': [p['count'] for p in predictions]
        }
    })

@app.route('/admin/download-predictions')
def download_predictions():
    if 'admin_id' not in session: return redirect(url_for('admin_login'))
    conn = get_db_connection()
    preds = conn.execute('SELECT * FROM predictions').fetchall()
    conn.close()
    
    df = pd.DataFrame([dict(p) for p in preds])
    output_path = 'predictions_export.csv'
    df.to_csv(output_path, index=False)
    return send_file(output_path, as_attachment=True)

@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('index'))

if __name__ == '__main__':
    os.makedirs('uploads', exist_ok=True)
    app.run(debug=True)
