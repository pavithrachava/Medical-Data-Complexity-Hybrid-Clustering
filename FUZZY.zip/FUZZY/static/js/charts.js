document.addEventListener('DOMContentLoaded', function() {
    // 1. Fetch data from Flask API
    fetch('/api/chart-data')
    .then(response => response.json())
    .then(data => {
        // --- PERFORMANCE METRICS (BAR CHART) ---
        const metricsCtx = document.getElementById('metricsChart');
        if (metricsCtx) {
            new Chart(metricsCtx, {
                type: 'bar',
                data: {
                    labels: data.metrics.labels,
                    datasets: [
                        {
                            label: 'Silhouette Score',
                            data: data.metrics.silhouette,
                            backgroundColor: 'rgba(31, 97, 141, 0.7)',
                            borderColor: '#1F618D',
                            borderWidth: 1
                        },
                        {
                            label: 'Davies-Bouldin Score',
                            data: data.metrics.db,
                            backgroundColor: 'rgba(23, 165, 137, 0.7)',
                            borderColor: '#17A589',
                            borderWidth: 1
                        }
                    ]
                },
                options: {
                    responsive: true,
                    plugins: {
                        legend: { position: 'top' },
                        title: { display: true, text: 'Model Performance Metrics' }
                    },
                    scales: { y: { beginAtZero: true } }
                }
            });
        }

        // --- DETECTION TYPE RATIO (PIE CHART) ---
        const ratioCtx = document.getElementById('ratioChart');
        if (ratioCtx) {
            new Chart(ratioCtx, {
                type: 'pie',
                data: {
                    labels: data.ratio.labels,
                    datasets: [{
                        data: data.ratio.data,
                        backgroundColor: [
                            '#1F618D', // Deep Blue
                            '#17A589', // Teal Green
                            '#F4D03F', // Gold
                            '#E67E22', // Orange (extra)
                            '#9B59B6'  // Purple (extra)
                        ],
                        hoverOffset: 10
                    }]
                },
                options: {
                    responsive: true,
                    plugins: {
                        legend: { position: 'bottom' },
                        title: { display: true, text: 'Detection Type Distribution' }
                    }
                }
            });
        }
    })
    .catch(error => console.error('Error fetching chart data:', error));
});
